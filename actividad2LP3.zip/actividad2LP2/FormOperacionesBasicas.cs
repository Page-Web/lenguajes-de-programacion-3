﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad2LP2


{

    public partial class FormOperacionesBasicas : Form
    {
        private double[] ObtenerNumeros()
        {
            return new double[] {
                double.Parse(txtNum1.Text),
                double.Parse(txtNum2.Text),
                double.Parse(txtNum3.Text),
                double.Parse(txtNum4.Text),
                double.Parse(txtNum5.Text),
                double.Parse(txtNum6.Text)
            };
                }
        public FormOperacionesBasicas()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            try
            {
                double[] nums = ObtenerNumeros();
                double suma = 0;
                foreach (double n in nums) suma += n;
                txtResultado.Text = suma.ToString();
            }
            catch { MessageBox.Show("Ingresa números válidos en las 6 casillas."); }
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            try
            {
                double[] nums = ObtenerNumeros();
                double resta = nums[0];
                for (int i = 1; i < nums.Length; i++) resta -= nums[i];
                txtResultado.Text = resta.ToString();
            }
            catch { MessageBox.Show("Ingresa números válidos en las 6 casillas."); }
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            try
            {
                double[] nums = ObtenerNumeros();
                double prod = 1;
                foreach (double n in nums) prod *= n;
                txtResultado.Text = prod.ToString();
            }
            catch { MessageBox.Show("Ingresa números válidos en las 6 casillas."); }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            try
            {
                double[] nums = ObtenerNumeros();
                double div = nums[0];
                for (int i = 1; i < nums.Length; i++)
                {
                    if (nums[i] == 0) { MessageBox.Show("No se puede dividir entre cero."); return; }
                    div /= nums[i];
                }
                txtResultado.Text = div.ToString("F4"); // 4 decimales
            }
            catch { MessageBox.Show("Ingresa números válidos en las 6 casillas."); }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear(); txtNum2.Clear(); txtNum3.Clear();
            txtNum4.Clear(); txtNum5.Clear(); txtNum6.Clear();
            txtResultado.Clear();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            FormMenu menu = new FormMenu();
            menu.Show();
            this.Close();
        }
    }
}
