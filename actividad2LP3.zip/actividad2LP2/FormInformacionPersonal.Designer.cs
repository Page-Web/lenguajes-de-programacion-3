﻿namespace actividad2LP2
{
    partial class FormInformacionPersonal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInformacionPersonal));
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.DatosPersonales = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRegresar1 = new System.Windows.Forms.Button();
            this.rbMujer = new System.Windows.Forms.RadioButton();
            this.rbHombre = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbEstadoCivil = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCiudad = new System.Windows.Forms.TextBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnRegresar2 = new System.Windows.Forms.Button();
            this.rbDepNo = new System.Windows.Forms.RadioButton();
            this.rbDepSi = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.rbEjerNo = new System.Windows.Forms.RadioButton();
            this.rbEjerSi = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.rbOpNo = new System.Windows.Forms.RadioButton();
            this.rbOpSi = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbAlergias = new System.Windows.Forms.ComboBox();
            this.rbAlergiaNo = new System.Windows.Forms.RadioButton();
            this.rbAlergiaSi = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.rbEnfNo = new System.Windows.Forms.RadioButton();
            this.rbEnfSi = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.DatosPersonales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Información personal";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.DatosPersonales);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(32, 48);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(756, 390);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.Tag = "";
            // 
            // DatosPersonales
            // 
            this.DatosPersonales.Controls.Add(this.pictureBox1);
            this.DatosPersonales.Controls.Add(this.btnRegresar1);
            this.DatosPersonales.Controls.Add(this.rbMujer);
            this.DatosPersonales.Controls.Add(this.rbHombre);
            this.DatosPersonales.Controls.Add(this.label8);
            this.DatosPersonales.Controls.Add(this.cmbEstadoCivil);
            this.DatosPersonales.Controls.Add(this.label7);
            this.DatosPersonales.Controls.Add(this.dtpFechaNacimiento);
            this.DatosPersonales.Controls.Add(this.label6);
            this.DatosPersonales.Controls.Add(this.txtCiudad);
            this.DatosPersonales.Controls.Add(this.txtDireccion);
            this.DatosPersonales.Controls.Add(this.txtApellido);
            this.DatosPersonales.Controls.Add(this.txtNombre);
            this.DatosPersonales.Controls.Add(this.label5);
            this.DatosPersonales.Controls.Add(this.label4);
            this.DatosPersonales.Controls.Add(this.label3);
            this.DatosPersonales.Controls.Add(this.label2);
            this.DatosPersonales.Location = new System.Drawing.Point(4, 25);
            this.DatosPersonales.Name = "DatosPersonales";
            this.DatosPersonales.Padding = new System.Windows.Forms.Padding(3);
            this.DatosPersonales.Size = new System.Drawing.Size(748, 361);
            this.DatosPersonales.TabIndex = 0;
            this.DatosPersonales.Text = "Datos Personales";
            this.DatosPersonales.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(574, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(168, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // btnRegresar1
            // 
            this.btnRegresar1.Location = new System.Drawing.Point(26, 293);
            this.btnRegresar1.Name = "btnRegresar1";
            this.btnRegresar1.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar1.TabIndex = 15;
            this.btnRegresar1.Text = "Regresar";
            this.btnRegresar1.UseVisualStyleBackColor = true;
            this.btnRegresar1.Click += new System.EventHandler(this.btnRegresar1_Click);
            // 
            // rbMujer
            // 
            this.rbMujer.AutoSize = true;
            this.rbMujer.Location = new System.Drawing.Point(390, 158);
            this.rbMujer.Name = "rbMujer";
            this.rbMujer.Size = new System.Drawing.Size(61, 20);
            this.rbMujer.TabIndex = 14;
            this.rbMujer.TabStop = true;
            this.rbMujer.Text = "Mujer";
            this.rbMujer.UseVisualStyleBackColor = true;
            // 
            // rbHombre
            // 
            this.rbHombre.AutoSize = true;
            this.rbHombre.Location = new System.Drawing.Point(307, 156);
            this.rbHombre.Name = "rbHombre";
            this.rbHombre.Size = new System.Drawing.Size(77, 20);
            this.rbHombre.TabIndex = 13;
            this.rbHombre.TabStop = true;
            this.rbHombre.Text = "Hombre";
            this.rbHombre.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(304, 137);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 16);
            this.label8.TabIndex = 12;
            this.label8.Text = "Sexo:";
            // 
            // cmbEstadoCivil
            // 
            this.cmbEstadoCivil.FormattingEnabled = true;
            this.cmbEstadoCivil.Items.AddRange(new object[] {
            "Soltero",
            "Casado",
            "Divorciado",
            "Viudo"});
            this.cmbEstadoCivil.Location = new System.Drawing.Point(307, 99);
            this.cmbEstadoCivil.Name = "cmbEstadoCivil";
            this.cmbEstadoCivil.Size = new System.Drawing.Size(121, 24);
            this.cmbEstadoCivil.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(304, 83);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Estado civil:";
            // 
            // dtpFechaNacimiento
            // 
            this.dtpFechaNacimiento.Location = new System.Drawing.Point(307, 45);
            this.dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            this.dtpFechaNacimiento.Size = new System.Drawing.Size(200, 22);
            this.dtpFechaNacimiento.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(304, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Fecha de nacimiento:";
            // 
            // txtCiudad
            // 
            this.txtCiudad.Location = new System.Drawing.Point(26, 217);
            this.txtCiudad.Name = "txtCiudad";
            this.txtCiudad.Size = new System.Drawing.Size(254, 22);
            this.txtCiudad.TabIndex = 7;
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(26, 156);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(254, 22);
            this.txtDireccion.TabIndex = 6;
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(26, 102);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(254, 22);
            this.txtApellido.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(26, 46);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(254, 22);
            this.txtNombre.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Ciudad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Direccion:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Apellido:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnRegresar2);
            this.tabPage2.Controls.Add(this.rbDepNo);
            this.tabPage2.Controls.Add(this.rbDepSi);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.comboBox3);
            this.tabPage2.Controls.Add(this.rbEjerNo);
            this.tabPage2.Controls.Add(this.rbEjerSi);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.rbOpNo);
            this.tabPage2.Controls.Add(this.rbOpSi);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.cmbAlergias);
            this.tabPage2.Controls.Add(this.rbAlergiaNo);
            this.tabPage2.Controls.Add(this.rbAlergiaSi);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.rbEnfNo);
            this.tabPage2.Controls.Add(this.rbEnfSi);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(748, 361);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Datos clínicos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnRegresar2
            // 
            this.btnRegresar2.Location = new System.Drawing.Point(646, 318);
            this.btnRegresar2.Name = "btnRegresar2";
            this.btnRegresar2.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar2.TabIndex = 19;
            this.btnRegresar2.Text = "Regresar";
            this.btnRegresar2.UseVisualStyleBackColor = true;
            this.btnRegresar2.Click += new System.EventHandler(this.btnRegresar2_Click);
            // 
            // rbDepNo
            // 
            this.rbDepNo.AutoSize = true;
            this.rbDepNo.Location = new System.Drawing.Point(92, 318);
            this.rbDepNo.Name = "rbDepNo";
            this.rbDepNo.Size = new System.Drawing.Size(46, 20);
            this.rbDepNo.TabIndex = 18;
            this.rbDepNo.TabStop = true;
            this.rbDepNo.Text = "No";
            this.rbDepNo.UseVisualStyleBackColor = true;
            // 
            // rbDepSi
            // 
            this.rbDepSi.AutoSize = true;
            this.rbDepSi.Location = new System.Drawing.Point(30, 318);
            this.rbDepSi.Name = "rbDepSi";
            this.rbDepSi.Size = new System.Drawing.Size(40, 20);
            this.rbDepSi.TabIndex = 17;
            this.rbDepSi.TabStop = true;
            this.rbDepSi.Text = "Si";
            this.rbDepSi.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 293);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(159, 16);
            this.label13.TabIndex = 16;
            this.label13.Text = "¿Padeces de depresión?";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Diario",
            "Ocasional",
            "2-3 Veces a la semana",
            "Nunca"});
            this.comboBox3.Location = new System.Drawing.Point(168, 251);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 24);
            this.comboBox3.TabIndex = 15;
            // 
            // rbEjerNo
            // 
            this.rbEjerNo.AutoSize = true;
            this.rbEjerNo.Location = new System.Drawing.Point(92, 251);
            this.rbEjerNo.Name = "rbEjerNo";
            this.rbEjerNo.Size = new System.Drawing.Size(46, 20);
            this.rbEjerNo.TabIndex = 14;
            this.rbEjerNo.TabStop = true;
            this.rbEjerNo.Text = "No";
            this.rbEjerNo.UseVisualStyleBackColor = true;
            // 
            // rbEjerSi
            // 
            this.rbEjerSi.AutoSize = true;
            this.rbEjerSi.Location = new System.Drawing.Point(30, 251);
            this.rbEjerSi.Name = "rbEjerSi";
            this.rbEjerSi.Size = new System.Drawing.Size(40, 20);
            this.rbEjerSi.TabIndex = 13;
            this.rbEjerSi.TabStop = true;
            this.rbEjerSi.Text = "Si";
            this.rbEjerSi.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 226);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 16);
            this.label12.TabIndex = 12;
            this.label12.Text = "¿Haces ejercicio?";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Apendicitis",
            "Fractura",
            "Amígdalas",
            "Ninguna"});
            this.comboBox2.Location = new System.Drawing.Point(168, 186);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 11;
            // 
            // rbOpNo
            // 
            this.rbOpNo.AutoSize = true;
            this.rbOpNo.Location = new System.Drawing.Point(92, 186);
            this.rbOpNo.Name = "rbOpNo";
            this.rbOpNo.Size = new System.Drawing.Size(46, 20);
            this.rbOpNo.TabIndex = 10;
            this.rbOpNo.TabStop = true;
            this.rbOpNo.Text = "No";
            this.rbOpNo.UseVisualStyleBackColor = true;
            // 
            // rbOpSi
            // 
            this.rbOpSi.AutoSize = true;
            this.rbOpSi.Location = new System.Drawing.Point(30, 186);
            this.rbOpSi.Name = "rbOpSi";
            this.rbOpSi.Size = new System.Drawing.Size(40, 20);
            this.rbOpSi.TabIndex = 9;
            this.rbOpSi.TabStop = true;
            this.rbOpSi.Text = "Si";
            this.rbOpSi.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(181, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "¿Alguna vez te han operado?";
            // 
            // cmbAlergias
            // 
            this.cmbAlergias.FormattingEnabled = true;
            this.cmbAlergias.Items.AddRange(new object[] {
            "Polen",
            "Medicamentos",
            "Alimentos",
            "Ninguna"});
            this.cmbAlergias.Location = new System.Drawing.Point(168, 115);
            this.cmbAlergias.Name = "cmbAlergias";
            this.cmbAlergias.Size = new System.Drawing.Size(121, 24);
            this.cmbAlergias.TabIndex = 7;
            // 
            // rbAlergiaNo
            // 
            this.rbAlergiaNo.AutoSize = true;
            this.rbAlergiaNo.Location = new System.Drawing.Point(92, 115);
            this.rbAlergiaNo.Name = "rbAlergiaNo";
            this.rbAlergiaNo.Size = new System.Drawing.Size(46, 20);
            this.rbAlergiaNo.TabIndex = 6;
            this.rbAlergiaNo.TabStop = true;
            this.rbAlergiaNo.Text = "No";
            this.rbAlergiaNo.UseVisualStyleBackColor = true;
            // 
            // rbAlergiaSi
            // 
            this.rbAlergiaSi.AutoSize = true;
            this.rbAlergiaSi.Location = new System.Drawing.Point(30, 115);
            this.rbAlergiaSi.Name = "rbAlergiaSi";
            this.rbAlergiaSi.Size = new System.Drawing.Size(40, 20);
            this.rbAlergiaSi.TabIndex = 5;
            this.rbAlergiaSi.TabStop = true;
            this.rbAlergiaSi.Text = "Si";
            this.rbAlergiaSi.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "¿Tienes alergias?";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Diabetes",
            "Hipertensión",
            "Asma",
            "Ninguna"});
            this.comboBox1.Location = new System.Drawing.Point(168, 49);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 3;
            // 
            // rbEnfNo
            // 
            this.rbEnfNo.AutoSize = true;
            this.rbEnfNo.Location = new System.Drawing.Point(92, 49);
            this.rbEnfNo.Name = "rbEnfNo";
            this.rbEnfNo.Size = new System.Drawing.Size(46, 20);
            this.rbEnfNo.TabIndex = 2;
            this.rbEnfNo.TabStop = true;
            this.rbEnfNo.Text = "No";
            this.rbEnfNo.UseVisualStyleBackColor = true;
            // 
            // rbEnfSi
            // 
            this.rbEnfSi.AutoSize = true;
            this.rbEnfSi.Location = new System.Drawing.Point(30, 49);
            this.rbEnfSi.Name = "rbEnfSi";
            this.rbEnfSi.Size = new System.Drawing.Size(40, 20);
            this.rbEnfSi.TabIndex = 1;
            this.rbEnfSi.TabStop = true;
            this.rbEnfSi.Text = "Si";
            this.rbEnfSi.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(215, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "¿Padeces de alguna enfermedad?";
            // 
            // FormInformacionPersonal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormInformacionPersonal";
            this.Text = "Datos";
            this.tabControl1.ResumeLayout(false);
            this.DatosPersonales.ResumeLayout(false);
            this.DatosPersonales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage DatosPersonales;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimiento;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCiudad;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnRegresar1;
        private System.Windows.Forms.RadioButton rbMujer;
        private System.Windows.Forms.RadioButton rbHombre;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbEstadoCivil;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbAlergias;
        private System.Windows.Forms.RadioButton rbAlergiaNo;
        private System.Windows.Forms.RadioButton rbAlergiaSi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton rbEnfNo;
        private System.Windows.Forms.RadioButton rbEnfSi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.RadioButton rbOpNo;
        private System.Windows.Forms.RadioButton rbOpSi;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton rbDepNo;
        private System.Windows.Forms.RadioButton rbDepSi;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.RadioButton rbEjerNo;
        private System.Windows.Forms.RadioButton rbEjerSi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnRegresar2;
    }
}