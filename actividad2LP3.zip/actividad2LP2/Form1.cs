﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad2LP2
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void saludoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSaludo frmSaludo = new FormSaludo();
            frmSaludo.Show();
            this.Hide(); // Oculta el menú temporalmente
        }

        private void datosPersonalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormInformacionPersonal frmInfo = new FormInformacionPersonal();
            frmInfo.Show();
            this.Hide();
        }

        private void operacionBasicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOperacionesBasicas frmOps = new FormOperacionesBasicas();
            frmOps.Show();
            this.Hide();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
    }
}
