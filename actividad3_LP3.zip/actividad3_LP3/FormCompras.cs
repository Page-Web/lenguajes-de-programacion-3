﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad3_LP3
{
    public partial class FormCompras : Form
    {
        public FormCompras()
        {
            InitializeComponent();
        }

        private void CargarCompras()
        {
            using (SqlConnection cn = ConexionBD.ObtenerConexion())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Compras", cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCompras.DataSource = dt;
            }
        }

        private void LimpiarCampos()
        {
            txtIdCompra.Clear();
            txtIdCliente.Clear();
            txtIdProducto.Clear();
            txtCantidad.Clear();
            txtFechaCompra.Clear();
        }

        private void FormCompras_Load(object sender, EventArgs e)
        {

        }

        private void Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Modificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdCompra.Text))
            {
                MessageBox.Show("Ingresa el IdCompra que deseas modificar.");
                return;
            }

            if (!int.TryParse(txtIdCompra.Text.Trim(), out int idCompra))
            {
                MessageBox.Show("El IdCompra debe ser un número válido.");
                return;
            }

            if (!int.TryParse(txtIdCliente.Text.Trim(), out int idCliente))
            {
                MessageBox.Show("Ingresa un IdCliente numérico válido que ya exista en Clientes.");
                return;
            }

            if (!int.TryParse(txtIdProducto.Text.Trim(), out int idProducto))
            {
                MessageBox.Show("Ingresa un IdProducto numérico válido que ya exista en Productos.");
                return;
            }

            if (!int.TryParse(txtCantidad.Text.Trim(), out int cantidad) || cantidad <= 0)
            {
                MessageBox.Show("Ingresa una cantidad entera mayor a 0.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"UPDATE Compras
                                 SET IdCliente = @IdCliente, IdProducto = @IdProducto,
                                     Cantidad = @Cantidad, FechaCompra = @FechaCompra
                                 WHERE IdCompra = @IdCompra";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdCompra", idCompra);
                    cmd.Parameters.AddWithValue("@IdCliente", idCliente);
                    cmd.Parameters.AddWithValue("@IdProducto", idProducto);
                    cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                    cmd.Parameters.AddWithValue("@FechaCompra", string.IsNullOrWhiteSpace(txtFechaCompra.Text) ? (object)DBNull.Value : txtFechaCompra.Text.Trim());

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("La compra fue modificada exitosamente");
                        CargarCompras();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró una compra con ese IdCompra.");
                    }
                }
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                MessageBox.Show("Error de llave foránea: verifica que IdCliente e IdProducto existan en sus respectivas tablas.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdCompra.Text))
            {
                MessageBox.Show("Ingresa el IdCompra que deseas eliminar.");
                return;
            }

            if (!int.TryParse(txtIdCompra.Text.Trim(), out int idCompra))
            {
                MessageBox.Show("El IdCompra debe ser un número válido.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = "DELETE FROM Compras WHERE IdCompra = @IdCompra";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdCompra", idCompra);

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("La compra fue eliminada exitosamente");
                        CargarCompras();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró una compra con ese IdCompra.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void Mostrar_Click(object sender, EventArgs e)
        {
            try
            {
                CargarCompras();
                MessageBox.Show("Datos consultados exitosamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar datos: " + ex.Message);
            }
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtIdCliente.Text.Trim(), out int idCliente))
            {
                MessageBox.Show("Ingresa un IdCliente numérico válido que ya exista en Clientes.");
                return;
            }

            if (!int.TryParse(txtIdProducto.Text.Trim(), out int idProducto))
            {
                MessageBox.Show("Ingresa un IdProducto numérico válido que ya exista en Productos.");
                return;
            }

            if (!int.TryParse(txtCantidad.Text.Trim(), out int cantidad) || cantidad <= 0)
            {
                MessageBox.Show("Ingresa una cantidad entera mayor a 0.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"INSERT INTO Compras (IdCliente, IdProducto, Cantidad, FechaCompra)
                                 VALUES (@IdCliente, @IdProducto, @Cantidad, @FechaCompra)";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdCliente", idCliente);
                    cmd.Parameters.AddWithValue("@IdProducto", idProducto);
                    cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                    cmd.Parameters.AddWithValue("@FechaCompra", string.IsNullOrWhiteSpace(txtFechaCompra.Text) ? (object)DBNull.Value : txtFechaCompra.Text.Trim());

                    cn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("La compra fue registrada exitosamente");
                CargarCompras();
                LimpiarCampos();
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                MessageBox.Show("Error de llave foránea: verifica que IdCliente e IdProducto existan en sus respectivas tablas.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }
    }
}
