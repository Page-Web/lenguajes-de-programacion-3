﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad3_LP3
{
    public partial class FormProductosCRUD : Form
    {
        public FormProductosCRUD()
        {
            InitializeComponent();
        }

        private void CargarProductos()
        {
            using (SqlConnection cn = ConexionBD.ObtenerConexion())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Productos", cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvProductos.DataSource = dt;
            }
        }

        private void LimpiarCampos()
        {
            txtIdProducto.Clear();
            txtCodigo.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
            txtTalla.Clear();
            txtCategoria.Clear();
            txtIdProveedor.Clear();
        }

        private bool TryParsePrecio(string texto, out decimal precio)
        {
            return decimal.TryParse(
                texto.Trim(),
                NumberStyles.Any,
                CultureInfo.CurrentCulture,
                out precio
            ) || decimal.TryParse(
                texto.Trim().Replace(',', '.'),
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out precio
            );
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            if (!TryParsePrecio(txtPrecio.Text, out decimal precio))
            {
                MessageBox.Show("Ingresa un precio válido (ej. 850.00).");
                return;
            }

            if (!int.TryParse(txtIdProveedor.Text.Trim(), out int idProveedor))
            {
                MessageBox.Show("Ingresa un IdProveedor numérico válido que ya exista en Proveedores.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"INSERT INTO Productos (Codigo, Nombre, Precio, Talla, Categoria, IdProveedor)
                                 VALUES (@Codigo, @Nombre, @Precio, @Talla, @Categoria, @IdProveedor)";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text.Trim());
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@Precio", precio);
                    cmd.Parameters.AddWithValue("@Talla", txtTalla.Text.Trim());
                    cmd.Parameters.AddWithValue("@Categoria", txtCategoria.Text.Trim());
                    cmd.Parameters.AddWithValue("@IdProveedor", idProveedor);

                    cn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("El producto fue agregado exitosamente");
                CargarProductos();
                LimpiarCampos();
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                MessageBox.Show("Error de llave foránea: el IdProveedor indicado no existe en la tabla Proveedores.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }

        private void Modificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdProducto.Text))
            {
                MessageBox.Show("Ingresa el IdProducto que deseas modificar.");
                return;
            }

            if (!int.TryParse(txtIdProducto.Text.Trim(), out int idProducto))
            {
                MessageBox.Show("El IdProducto debe ser un número válido.");
                return;
            }

            if (!TryParsePrecio(txtPrecio.Text, out decimal precio))
            {
                MessageBox.Show("Ingresa un precio válido (ej. 850.00).");
                return;
            }

            if (!int.TryParse(txtIdProveedor.Text.Trim(), out int idProveedor))
            {
                MessageBox.Show("Ingresa un IdProveedor numérico válido que ya exista en Proveedores.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"UPDATE Productos
                                 SET Codigo = @Codigo, Nombre = @Nombre, Precio = @Precio,
                                     Talla = @Talla, Categoria = @Categoria, IdProveedor = @IdProveedor
                                 WHERE IdProducto = @IdProducto";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdProducto", idProducto);
                    cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text.Trim());
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@Precio", precio);
                    cmd.Parameters.AddWithValue("@Talla", txtTalla.Text.Trim());
                    cmd.Parameters.AddWithValue("@Categoria", txtCategoria.Text.Trim());
                    cmd.Parameters.AddWithValue("@IdProveedor", idProveedor);

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("El producto fue modificado exitosamente");
                        CargarProductos();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un producto con ese IdProducto.");
                    }
                }
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                MessageBox.Show("Error de llave foránea: el IdProveedor indicado no existe en la tabla Proveedores.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdProducto.Text))
            {
                MessageBox.Show("Ingresa el IdProducto que deseas eliminar.");
                return;
            }

            if (!int.TryParse(txtIdProducto.Text.Trim(), out int idProducto))
            {
                MessageBox.Show("El IdProducto debe ser un número válido.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = "DELETE FROM Productos WHERE IdProducto = @IdProducto";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdProducto", idProducto);

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("El producto fue eliminado exitosamente");
                        CargarProductos();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un producto con ese IdProducto.");
                    }
                }
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                MessageBox.Show("No se puede eliminar este producto porque está referenciado en Compras.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void Mostrar_Click(object sender, EventArgs e)
        {
            try
            {
                CargarProductos();
                MessageBox.Show("Datos consultados exitosamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar datos: " + ex.Message);
            }
        }

        private void Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
