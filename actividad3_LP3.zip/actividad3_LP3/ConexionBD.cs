﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actividad3_LP3
{
    public class ConexionBD
    {
        public static string CadenaConexion =
            @"Server=localhost;Database=ZapateriaUMI_CRUD;Trusted_Connection=True;";

        public static SqlConnection ObtenerConexion()
        {
            return new SqlConnection(CadenaConexion);
        }
    }
}
