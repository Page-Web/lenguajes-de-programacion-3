﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad3_LP3
{
    public partial class FormClientes : Form
    {
        public FormClientes()
        {
            InitializeComponent();
        }

        private void FormClientes_Load(object sender, EventArgs e)
        {

        }

        private void CargarClientes()
        {
            using (SqlConnection cn = ConexionBD.ObtenerConexion())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Clientes", cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvClientes.DataSource = dt;
            }
        }

        private void LimpiarCampos()
        {
            txtIdCliente.Clear();
            txtDNI.Clear();
            txtNombre.Clear();
            txtApellidos.Clear();
            txtFechaNac.Clear();
            txtTelefono.Clear();
            txtEmail.Clear();
        }

        private void Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Mostrar_Click(object sender, EventArgs e)
        {
            try
            {
                CargarClientes();
                MessageBox.Show("Datos consultados exitosamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar datos: " + ex.Message);
            }
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"INSERT INTO Clientes (DNI, Nombre, Apellidos, FechaNac, Telefono, Email)
                                 VALUES (@DNI, @Nombre, @Apellidos, @FechaNac, @Telefono, @Email)";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@DNI", txtDNI.Text.Trim());
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@Apellidos", txtApellidos.Text.Trim());
                    cmd.Parameters.AddWithValue("@FechaNac", string.IsNullOrWhiteSpace(txtFechaNac.Text) ? (object)DBNull.Value : txtFechaNac.Text.Trim());
                    cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());

                    cn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("El usuario fue agregado exitosamente");
                CargarClientes();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }

        private void Modificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdCliente.Text))
            {
                MessageBox.Show("Ingresa el IdCliente que deseas modificar.");
                return;
            }

            if (!int.TryParse(txtIdCliente.Text.Trim(), out int idCliente))
            {
                MessageBox.Show("El IdCliente debe ser un número válido.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"UPDATE Clientes
                                 SET DNI = @DNI, Nombre = @Nombre, Apellidos = @Apellidos,
                                     FechaNac = @FechaNac, Telefono = @Telefono, Email = @Email
                                 WHERE IdCliente = @IdCliente";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdCliente", idCliente);
                    cmd.Parameters.AddWithValue("@DNI", txtDNI.Text.Trim());
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@Apellidos", txtApellidos.Text.Trim());
                    cmd.Parameters.AddWithValue("@FechaNac", string.IsNullOrWhiteSpace(txtFechaNac.Text) ? (object)DBNull.Value : txtFechaNac.Text.Trim());
                    cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("El cliente fue modificado exitosamente");
                        CargarClientes();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un cliente con ese IdCliente.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdCliente.Text))
            {
                MessageBox.Show("Ingresa el IdCliente que deseas eliminar.");
                return;
            }

            if (!int.TryParse(txtIdCliente.Text.Trim(), out int idCliente))
            {
                MessageBox.Show("El IdCliente debe ser un número válido.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = "DELETE FROM Clientes WHERE IdCliente = @IdCliente";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdCliente", idCliente);

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("El cliente fue eliminado exitosamente");
                        CargarClientes();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un cliente con ese IdCliente.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }
    }
}
