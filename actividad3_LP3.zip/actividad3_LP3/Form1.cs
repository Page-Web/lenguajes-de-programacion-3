﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad3_LP3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPassword pass = new FormPassword();
            pass.FormularioDestino = "Cliente";
            pass.ShowDialog();
        }

        private void mensajeDeBienvenidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bienvenido a la tienda en linea ZAPATERIA UMI, donde podra encontrar todo lo que usted necesita y si no lo encuentra se lo conseguimos. Somos su mejor opcion hoy y siempre.", "Bienvenida");
        }

        private void quiénesSomosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Somos una empresa mexicana, que trata de apoyar al comercio mexicano, todos nuestros productos son 100% mexicanos, por que creemos en nosotros y por que sabemos que podemos.", "¿Quiénes Somos?");
        }

        private void misiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nuestra mision es darnos a conocer a nivel nacional y lograr el objetivo de que todos los mexicanos utilicen productos mexicanos, que abramos los ojos y veamos que no por que el producto sea de otro pais, signifique que es mejor.", "Misión");
        }

        private void visiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nuestra vision es que una vez que nos encontremos a nivel nacional, buscaremos el mercado internacional y llevaremos el nombre de nusetro producto, de nuestro pais, a todo el mundo para que sepan de lo que somos capaces.", "Visión");
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void registroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void proveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPassword pass = new FormPassword();
            pass.FormularioDestino = "Proveedor";
            pass.ShowDialog();
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPassword pass = new FormPassword();
            pass.FormularioDestino = "Producto";
            pass.ShowDialog();
        }

        private void damasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDamas formDamas = new FormDamas();
            formDamas.Show();
        }

        private void caballerosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCaballeros formCaballeros = new FormCaballeros();
            formCaballeros.Show();
        }

        private void comprasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCompras formCompras = new FormCompras();
            formCompras.Show();
        }
    }
}
