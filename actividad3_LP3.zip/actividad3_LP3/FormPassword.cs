﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad3_LP3
{
    public partial class FormPassword : Form
    {

        public string FormularioDestino;
        public FormPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtClave.Text == "1234")
            {
                if (FormularioDestino == "Cliente") new FormClientes().Show();
                else if (FormularioDestino == "Proveedor") new FormProveedores().Show();
                else if (FormularioDestino == "Producto") new FormProductosCRUD().Show();

                this.Close();
            }
            else
            {
                MessageBox.Show("Contraseña incorrecta", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
