﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace actividad3_LP3
{
    public partial class FormProveedores : Form
    {
        public FormProveedores()
        {
            InitializeComponent();
        }

        private void CargarProveedores()
        {
            using (SqlConnection cn = ConexionBD.ObtenerConexion())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Proveedores", cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvProveedores.DataSource = dt;
            }
        }

        private void LimpiarCampos()
        {
            txtIdProveedor.Clear();
            txtNIF.Clear();
            txtNombre.Clear();
            txtDireccion.Clear();
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdProveedor.Text))
            {
                MessageBox.Show("Ingresa el IdProveedor que deseas eliminar.");
                return;
            }

            if (!int.TryParse(txtIdProveedor.Text.Trim(), out int idProveedor))
            {
                MessageBox.Show("El IdProveedor debe ser un número válido.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = "DELETE FROM Proveedores WHERE IdProveedor = @IdProveedor";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdProveedor", idProveedor);

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("El proveedor fue eliminado exitosamente");
                        CargarProveedores();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un proveedor con ese IdProveedor.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void Modificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdProveedor.Text))
            {
                MessageBox.Show("Ingresa el IdProveedor que deseas modificar.");
                return;
            }

            if (!int.TryParse(txtIdProveedor.Text.Trim(), out int idProveedor))
            {
                MessageBox.Show("El IdProveedor debe ser un número válido.");
                return;
            }

            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"UPDATE Proveedores
                                 SET NIF = @NIF, Nombre = @Nombre, Direccion = @Direccion
                                 WHERE IdProveedor = @IdProveedor";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@IdProveedor", idProveedor);
                    cmd.Parameters.AddWithValue("@NIF", txtNIF.Text.Trim());
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@Direccion", txtDireccion.Text.Trim());

                    cn.Open();
                    int filas = cmd.ExecuteNonQuery();

                    if (filas > 0)
                    {
                        MessageBox.Show("El proveedor fue modificado exitosamente");
                        CargarProveedores();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un proveedor con ese IdProveedor.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection cn = ConexionBD.ObtenerConexion())
                {
                    string sql = @"INSERT INTO Proveedores (NIF, Nombre, Direccion)
                                 VALUES (@NIF, @Nombre, @Direccion)";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@NIF", txtNIF.Text.Trim());
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@Direccion", txtDireccion.Text.Trim());

                    cn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("El proveedor fue agregado exitosamente");
                CargarProveedores();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }

        private void dgvProveedores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Mostrar_Click(object sender, EventArgs e)
        {
            try
            {
                CargarProveedores();
                MessageBox.Show("Datos consultados exitosamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar datos: " + ex.Message);
            }
        }

        private void Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
